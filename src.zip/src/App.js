import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router';
import Home2 from './Home2';
import Navbar from './Navbar';
import Serch from './Serch';
import Video from './Video';
import PhotoDetails from './PhotoDetails';
import Footer from './Footer';
import About from './About';
import Contact from './Contact';

function App() {
  return (
    <div>
     <BrowserRouter>
     <Navbar/>
      <Serch/>
      <Routes>
        <Route path='/' element={<Home2/>}></Route>
        <Route path='/photodetail' element={<PhotoDetails/>}></Route>
        <Route path='/videos' element={<Video/>}></Route>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/contact' element={<Contact/>}></Route>
      </Routes>
      <Footer/>
     </BrowserRouter>
    </div>
  );
}

export default App;
