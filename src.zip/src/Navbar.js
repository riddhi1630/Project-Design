import React from 'react'
import { Link } from 'react-router'

function Navbar() {
    return (
       
            <div>
                
                <nav className="navbar navbar-expand-lg">
                    <div className="container-fluid">
                        <a className="navbar-brand" href="#">
                            <i className="fas fa-film mr-2" />
                            Catalog-Z
                        </a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i className="fas fa-bars" />
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ml-auto mb-2 mb-lg-0">
                                <li className="nav-item">
                                <Link className="nav-link nav-link-1 "  to="/">Photos</Link> 
                                </li>
                                <li className="nav-item">
                                <Link className="nav-link nav-link-2" to="/videos">Videos</Link>
                                </li>
                                <li className="nav-item">
                                <Link className="nav-link nav-link-3" to="/about">About</Link>
                                </li>
                                <li className="nav-item">
                                <Link className="nav-link nav-link-4" to="/contact">Contact</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

      
    )
}

export default Navbar
